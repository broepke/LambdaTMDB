import requests # Available via AWS Lambda Layer
import json # Available via AWS Lambda Layer
import os # Available via AWS Lambda Layer
import logging # Available via AWS Lambda Layer
import tmdbsimple as tmdb # https://github.com/celiao/tmdbsimple


headers = {"X-Aws-Parameters-Secrets-Token": os.environ.get("AWS_SESSION_TOKEN")}

# Logging events are sent to CloudWatch Logs
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def get_tmdb_api_key():
    """Use the AWS secrets manager (chanced as Lambda Layer) to get the TMDB API key.

    Returns:
        str: TMDB_API_KEY
    """

    secrets_extension_endpoint = (
        "http://localhost:"
        + "2773"
        + "/secretsmanager/get?secretId="
        + "arn:aws:secretsmanager:us-east-1:222975130657:secret:TMDB-c6Ii4F"
    )

    r = requests.get(secrets_extension_endpoint, headers=headers)
    secret = json.loads(r.text)["SecretString"]
    secret = json.loads(secret)
    TMDB_API_KEY = secret["TMDB_API"]

    return TMDB_API_KEY